                                                    
Huandrio Avelino e João Antônio

ADS671.


							  --- PARA FUNCIONAR ---


-Abra e execute SQLSERVER.




